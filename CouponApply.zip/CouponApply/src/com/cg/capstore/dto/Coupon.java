package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="coupon")
public class Coupon {
	
	@Id
	@Column(name="coupon_id")
	private String couponCode;
	
	@Column(name="amount")
	private double couponAmt;
	
	public Coupon(String couponCode, double couponAmt) {
		super();
		
		this.couponCode = couponCode;
		this.couponAmt = couponAmt;
	}

	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public double getCouponAmt() {
		return couponAmt;
	}
	public void setCouponAmt(double couponAmt) {
		this.couponAmt = couponAmt;
	}
	public Coupon() {
		super();
	}

}
