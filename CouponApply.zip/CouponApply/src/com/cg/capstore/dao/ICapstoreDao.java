package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.dto.Coupon;
import com.cg.capstore.dto.Order;

public interface ICapstoreDao {

	public List<Coupon> getAllCoupon(Coupon c);
	public List<Order> getAllOrderDetails(Order o);
	public Coupon search(String couponcode);
	public boolean couponVal(String couponCode);
}
