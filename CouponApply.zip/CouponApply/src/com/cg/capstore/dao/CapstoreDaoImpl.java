package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.cg.capstore.dto.Coupon;
import com.cg.capstore.dto.Order;

@Repository("couponDao")
public class CapstoreDaoImpl implements ICapstoreDao {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public List<Coupon> getAllCoupon(Coupon c) {
		String str="FROM Coupon";    
		TypedQuery<Coupon> query=em.createQuery(str,Coupon.class);
		return query.getResultList();	
	}

	@Override
	public List<Order> getAllOrderDetails(Order o) {
		String str="FROM Order";
		TypedQuery<Order> query=em.createQuery(str,Order.class);
		return query.getResultList();
	}
	
	public Coupon search(String couponcode){
		Coupon c = em.find(Coupon.class, couponcode);
		return c;
	}

	@Override
	public boolean couponVal(String couponCode) {
		Coupon c1= em.find(Coupon.class, couponCode);
		if(c1 != null)
			return true;
		else
			return false;	
	}

}
