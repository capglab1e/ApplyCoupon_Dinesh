package com.cg.capstore.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.cg.capstore.dto.Coupon;
import com.cg.capstore.dto.Order;
import com.cg.capstore.service.ICapstoreService;

@Controller
public class CouponController {
	
	@Autowired
	ICapstoreService couponservice;
	
	
	@RequestMapping(value="applyCoupon",method=RequestMethod.GET)
	public String searchData(@ModelAttribute("yy") Coupon c) {
		return "couponapply";
	}
	
	@RequestMapping(value="applycoupon",method=RequestMethod.POST)
	public ModelAndView couponApply(@ModelAttribute("yy") Coupon c){
		Order o = null;
		double finalPrice=0;
		if(couponservice.couponVal(c.getCouponCode())){
		Coupon co = couponservice.search(c.getCouponCode());
		String id = co.getCouponCode();
		List<Order> li = couponservice.getAllOrderDetails(o);
		for(Order order : li){
			if(order.getCouponCode().equals(id)){
				double d = order.getTotalPrice();
				double price = co.getCouponAmt();
				finalPrice = d-price;
			}
			}
		return new ModelAndView("couponsuccess","temp",finalPrice);
		}
		else{
			return new ModelAndView("couponfailure");
		}
	}
}
