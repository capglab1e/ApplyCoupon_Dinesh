package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Coupon;
import com.cg.capstore.dto.Order;

public interface ICapstoreService {

	public List<Coupon> getAllCoupon(Coupon c);
	public List<Order> getAllOrderDetails(Order o);
	public Coupon search(String string);
	public boolean couponVal(String couponCode);
}
